<div class="container has-text-centered">
    <p class="title">
        Share Your Image Now!
    </p>
    <p class="subtitle">
        <a href="?page=pages/share">[ Upload ]</a>
    </p>
</div>