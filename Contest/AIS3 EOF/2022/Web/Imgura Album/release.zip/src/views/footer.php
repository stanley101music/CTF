    </div>
    <hr>
    <footer>
        <p>&copy; <?= date('Y') ?> Imgura Album</p>
    </footer>
</body>

</html>
