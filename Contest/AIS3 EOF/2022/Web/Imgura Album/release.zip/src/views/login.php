<?php include 'header.php'; ?>
<form action="/login" method="POST">
    <input type="text" name="username" placeholder="username">
    <input type="submit" value="Login">
</form>
<?php include 'footer.php'; ?>
