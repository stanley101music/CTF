<?php
require '../lib/class.album.php';
require '../lib/class.user.php';
session_start();
