#!/bin/bash
docker build -t myfs_myfs .