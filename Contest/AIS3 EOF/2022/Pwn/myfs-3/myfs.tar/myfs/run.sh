#!/bin/bash

python3 /path_to_myfs/pow.py